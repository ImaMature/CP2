package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;

public class ACoinlistController {

	@FXML
    private Button ADeletebtn;

    @FXML
    private Button ARegisterbtn;

    @FXML
    private Button AUpdatebtn;

    @FXML
    private TableView<?> CoinList;

    @FXML
    void ADeleteAction(ActionEvent event) {

    }

    @FXML
    void ARegisterAction(ActionEvent event) {

    }

    @FXML
    void AUpdateAction(ActionEvent event) {

    }
	
}