package DAO;

public class TradeDAO {
	
}